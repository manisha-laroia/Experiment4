let dataServer;
let pubKey = 'pub-c-2d99e48e-d74e-47b7-b0af-703f8939ff01';
let subKey = 'sub-c-975c63e0-fff0-11e9-851d-46cd86668ce5';
let channelName = "window6";


let win = [];
let ghost;



function preload() {
  ghost = loadImage('Images/img0.png');
}



function setup() {

  createCanvas(windowWidth, windowHeight);
  background(0);


  dataServer = new PubNub({
    publish_key: pubKey, //get these from the pubnub account online
    subscribe_key: subKey,
    ssl: true
  });


  dataServer.addListener({
    message: readIncoming
  });
  dataServer.subscribe({
    channels: [channelName]
  });

  win.push(new windowMaker(mouseX, mouseY, dataServer.getUUID()));
  console.log(dataServer.getUUID());
  setInterval(wheresMyCursor, 300);
}




function draw() {
  //background(0);

  let totalX = 0;
  let totalY = 0;

  for (let i = 0; i < win.length; i++) {
    win[i].display();
    totalX += win[i].xpos;
    totalY += win[i].ypos;
  }
}




function mouseClicked() {
  clicks.push(new Clickpoints(avgX, avgY));
}




function readIncoming(inMessage) //when new data comes in it triggers this function, 
{ // this works becsuse we subscribed to the channel in setup()
  //console.log(inMessage.publisher);
  if (inMessage.channel == channelName) {
    let whoAreYou = inMessage.publisher;
    let clickX = inMessage.message.x;
    let clickY = inMessage.message.y;
    console.log(win.length);


    let newinput = true;
    for (let i = 0; i < win.length; i++) {
      if (whoAreYou == win[i].who) {
        win[i].xpos = clickX;
        win[i].ypos = clickY;
        newinput = false;
      }
    }
    if (newinput) {
      win.push(new windowMaker(clickX, clickY, whoAreYou));

    }



  }
}


function wheresMyCursor() {

  if (dist(mouseX, mouseY, win[0].xpos, win[0].ypos) > 1) {
    dataServer.publish({
      channel: channelName,
      message: {
        x: mouseX,
        y: mouseY
      }
    });

  } else {

  }
}

















///////////////////////////////////////////////////
function windowMaker(x, y, who) {
  this.xpos = x;
  this.ypos = y;
  this.who = who;
  
 this.rectx = int((windowWidth / 16) * int(random(0, 15)));
  this.recty = int((windowHeight / 9) * int(random(0, 8)));
 this.w = windowWidth / 16;
  this.h = windowHeight / 9;

  this.prevX = x;
  this.prevY = y;

  this.display = function() {
    
    imageMode(CENTER);
   fill(255, 190, 0, 128);
   rect(this.rectx, this.recty, this.w, this.h);
    image(ghost, this.xpos, this.ypos, this.h, this.h);

  }
}